<?php
//include 'includes/header.php';
include 'includes/connect.php';
session_start();

$user_id = $_SESSION['user_id'] ?? null;

if ($user_id) {
    // Fetch latest cycle data
    $sql = "SELECT * FROM menstrual_cycles WHERE user_id='$user_id' ORDER BY start_date DESC LIMIT 1";
    $result = $conn->query($sql);
    $cycle = $result->fetch_assoc();

    if ($cycle) {
        // Calculate fertile window
        $ovulation_day = date('Y-m-d', strtotime($cycle['start_date'] . ' +14 days'));
        $fertile_start = date('Y-m-d', strtotime($ovulation_day . ' -3 days'));
        $fertile_end = date('Y-m-d', strtotime($ovulation_day . ' +1 days'));
    } else {
        $no_data_message = "No cycle data found. Please track your cycle first.";
    }

    // Fetch latest symptoms
    $sql_symptoms = "SELECT * FROM symptoms WHERE user_id='$user_id' ORDER BY date_logged DESC LIMIT 5";
    $result_symptoms = $conn->query($sql_symptoms);
} else {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fertile Window</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('https://asiapacific.unfpa.org/sites/default/files/mhm.22.2.011_0.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .navbar {
            background-color: rgba(42, 61, 127, 0.8);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: center;
            width: 100%;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .info-cards {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .card {
            background-color: rgba(42, 61, 127, 0.8);
            color: #f0e4d7;
            padding: 15px;
            border-radius: 10px;
            width: 200px;
            margin: 10px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }

        .card img {
            width: 80px;
            height: auto;
            margin-bottom: 10px;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .symptoms {
            margin-top: 20px;
            padding: 15px;
            background: rgba(42, 61, 127, 0.1);
            border-radius: 10px;
        }

        .symptoms h2 {
            color: #2a3d7f;
        }

        .footer {
            background-color: rgba(42, 61, 127, 0.8);
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        button.notification {
            background-color: rgba(42, 61, 127, 0.8);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
        }

        button.notification:hover {
            background-color: rgba(42, 61, 127, 1);
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h2>Your Fertile Window</h2>
    </div>

    <div class="container">
        <?php if (isset($no_data_message)) { ?>
            <p style="color:red;"><?php echo $no_data_message; ?></p>
        <?php } else { ?>
            <div class="info-cards">
                <div class="card">
                    <img src="https://cdn-icons-png.flaticon.com/512/4825/4825073.png" alt="Period Icon">
                    <h2>Start</h2>
                    <p><strong><?php echo $fertile_start; ?></strong></p>
                </div>
                <div class="card">
                    <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Ovulation Icon">
                    <h2>Ovulation Day</h2>
                    <p><strong><?php echo $ovulation_day; ?></strong></p>
                </div>
                <div class="card">
                    <img src="https://cdn-icons-png.flaticon.com/512/2917/2917995.png" alt="Fertile Window Icon">
                    <h2>End</h2>
                    <p><strong><?php echo $fertile_end; ?></strong></p>
                </div>
            </div>
        <?php } ?>

        <div class="symptoms">
            <h2>Recent Symptoms</h2>
            <?php while ($symptom = $result_symptoms->fetch_assoc()) { ?>
                <p><strong><?php echo $symptom['date_logged']; ?>:</strong> <?php echo $symptom['symptom']; ?></p>
            <?php } ?>
        </div>

        <?php if (!isset($no_data_message)) { ?>
            <button class="notification" onclick="notifyUser()">Notify Me</button>
        <?php } ?>
    </div>

    <script>
        function notifyUser() {
            alert('You will be notified about your fertile days.');
        }
    </script>
</body>
</html>
