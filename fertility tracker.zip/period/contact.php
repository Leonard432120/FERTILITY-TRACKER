<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Fertility Tracker</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('https://asiapacific.unfpa.org/sites/default/files/mhm.22.2.011_0.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            color: #2a3d7f;
        }

        .sidebar {
            width: 200px;
            background-color: rgba(42, 61, 127, 0.9);
            color: #f0e4d7;
            padding: 20px;
            height: 100vh;
            position: fixed;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 1.5em;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px;
            text-align: center;
        }

        .sidebar ul li a {
            color: #f0e4d7;
            text-decoration: none;
            display: block;
            font-size: 1em;
        }

        .sidebar ul li:hover {
            background-color: rgba(240, 228, 215, 0.2);
        }

        .content-container {
            margin-left: 220px;
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .content-container h1 {
            font-size: 2.5em;
            background-color: rgba(240, 228, 215, 0.8);
            border-radius: 10px;
            padding: 10px;
            display: inline-block;
            color: #2a3d7f;
        }

        .content-container form {
            max-width: 600px;
            width: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
        }

        .content-container label {
            margin-bottom: 10px;
            font-weight: bold;
        }

        .content-container input,
        .content-container textarea {
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
        }

        .content-container button {
            padding: 10px;
            background-color: #2a3d7f;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .content-container button:hover {
            background-color: #1a275d;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="about_us.php">About Us</a></li>
            <li><a href="contact_us.php">Contact Us</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="content-container">
        <h1>Contact Us</h1>
        <form action="send_message.php" method="post">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="message">Message</label>
            <textarea id="message" name="message" rows="6" required></textarea>

            <button type="submit">Send Message</button>
        </form>
    </div>
</body>
</html>
