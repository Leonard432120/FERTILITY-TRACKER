document.addEventListener("DOMContentLoaded", function() {
    let nextPeriodDate = new Date(document.getElementById("nextPeriod").innerText);
    let today = new Date();

    let timeDiff = nextPeriodDate - today;
    let daysLeft = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));

    if (daysLeft <= 3) {
        alert("🚨 Reminder: Your next period is in " + daysLeft + " days!");
    }
});
