<?php
include 'includes/connect.php';
session_start();
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    header("Location: users/login.php");
    exit();
}
// Get latest menstrual cycle data
$sql_cycle = "SELECT * FROM menstrual_cycles WHERE user_id='$user_id' ORDER BY start_date DESC LIMIT 1";
$result_cycle = $conn->query($sql_cycle);
$cycle = $result_cycle->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fertility Tracker Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/png" href="image/app_launcher_icon.png">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('https://asiapacific.unfpa.org/sites/default/files/mhm.22.2.011_0.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            color: #2a3d7f;
        }

        .sidebar {
            width: 200px;
            background-color: rgba(42, 61, 127, 0.9);
            color: #f0e4d7;
            padding: 20px;
            height: 100vh;
            position: fixed;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 1.5em;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px;
            text-align: center;
        }

        .sidebar ul li a {
            color: #f0e4d7;
            text-decoration: none;
            display: block;
            font-size: 1em;
        }

        .sidebar ul li:hover {
            background-color: rgba(240, 228, 215, 0.2);
        }

        .dashboard-container {
            margin-left: 220px;
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .welcome-message {
            text-align: center;
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .welcome-message h1 {
            font-size: 2.5em;
            background-color: rgba(240, 228, 215, 0.8);
            border-radius: 10px;
            padding: 10px 20px;
            display: inline-block;
            color: #2a3d7f;
            vertical-align: middle;
        }

        .welcome-message img {
            vertical-align: middle;
            margin-right: 15px;
            width: 50px; /* Adjusted size to better fit the h1 */
            height: 50px; /* Adjusted size to better fit the h1 */
        }

        .website-title {
            font-size: 1.2em;
            color: #2a3d7f;
            margin-top: 10px;
        }

        .cards-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .card {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            padding: 20px;
            margin: 10px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            width: 260px;
            text-align: center;
            transition: transform 0.2s ease-in-out;
        }

        .card:hover {
            transform: scale(1.08);
        }

        .card img {
            width: 60px;
            height: 60px;
            margin-bottom: 15px;
        }

        .card h3 {
            font-size: 1.5em;
            color: #2a3d7f;
            margin-bottom: 10px;
        }

        .card p {
            font-size: 1em;
            color: #555;
            margin-bottom: 20px;
        }
        .card a {
            color: #2a3d7f;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.1em;
        }

        .card a:hover {
            text-decoration: underline;
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
            text-align: center;
            border-radius: 10px;
            animation: fadeIn 0.5s;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover, .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        @keyframes fadeIn {
            from {opacity: 0;} to {opacity: 1;}
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="track.php">Track Cycle</a></li>
            <li><a href="fertile.php">Fertile Days</a></li>
            <li><a href="safe-days.php">Safe Days</a></li>
            <li><a href="email_notify.php">Email Reminders</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="dashboard-container">
        <div class="welcome-message">
            <img src="image/app_launcher_icon.png" alt="Icon">
            <h1>Welcome to Fertility Tracker!</h1>
            <div class="website-title">Your Personal Fertility Management Tool</div>
        </div>
        
        <div class="cards-container">
            <div class="card">
                <img src="https://cdn-icons-png.flaticon.com/512/3135/3135730.png" alt="Track Cycle Icon">
                <h3>Track Your Cycle</h3>
                <p>Start tracking your menstrual cycle today.</p>
                <a href="track.php">Go to Tracker</a>
            </div>

            <div class="card">
                <img src="https://cdn-icons-png.flaticon.com/512/3135/3135728.png" alt="Fertile Days Icon">
                <h3>Fertile Days</h3>
                <p>Check your fertile window for better planning.</p>
                <a href="fertile.php">View Fertile Days</a>
            </div>

            <div class="card">
                <img src="https://cdn-icons-png.flaticon.com/512/3135/3135722.png" alt="Safe Days Icon">
                <h3>Safe Days</h3>
                <p>Know your safe days for pregnancy prevention.</p>
                <a href="safe-days.php">See Safe Days</a>
            </div>

            <div class="card">
                <img src="https://cdn-icons-png.flaticon.com/512/2917/2917995.png" alt="Email Icon">
                <h3>Email Reminders</h3>
                <p>Get notified about your upcoming period.</p>
                <a href="email_notify.php">Set Up Reminders</a>
            </div>
        </div>
    </div>

    <!-- The Modal -->
    <div id="modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p>Your Last Period Started On: <?php echo $cycle['start_date']; ?></p>
        </div>
    </div>

    <script>
        // Modal script
        var modal = document.getElementById("modal");
        var span = document.getElementsByClassName("close")[0];

        span.onclick = function() {
            modal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        // Automatically show the modal after page load
        window.onload = function() {
            modal.style.display = "block";
        }
    </script>
</body>
</html>
