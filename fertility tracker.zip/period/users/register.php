<?php
include '../includes/connect.php';

if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $cycle_length = $_POST['cycle_length'];
    $period_length = $_POST['period_length'];

    $sql = "INSERT INTO users (name, email, user_password, cycle_length, period_length)
            VALUES ('$name', '$email', '$password', '$cycle_length', '$period_length')";

    if ($conn->query($sql) === TRUE) {
        echo "Registration successful! <a href='login.php'>Login</a>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Fertility Tracker</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f5;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #2a3d7f;
            padding: 10px;
            color: white;
            text-align: center;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #2a3d7f;
            text-align: center;
        }

        .form-group {
            margin-bottom: 15px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ddd;
            font-size: 16px;
        }

        button {
            background-color: #2a3d7f;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            width: 100%;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #1d2d6a;
        }

        .footer {
            background-color: #2a3d7f;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

    </style>
</head>
<body>

    <!-- Navbar -->
    <div class="navbar">
        <h2>Fertility Tracker Registration</h2>
    </div>

    <!-- Registration Form -->
    <div class="container">
        <h1>Create an Account</h1>
        <form method="POST">
            <div class="form-group">
                <input type="text" name="name" placeholder="Full Name" required>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <input type="number" name="cycle_length" placeholder="Cycle Length (days)" value="28">
            </div>
            <div class="form-group">
                <input type="number" name="period_length" placeholder="Period Length (days)" value="5">
            </div>
            <button type="submit" name="register">Register</button>
        </form>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2025 Fertility Tracker | All rights reserved</p>
    </div>

</body>
</html>
