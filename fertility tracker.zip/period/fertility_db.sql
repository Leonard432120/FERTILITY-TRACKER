-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 20, 2025 at 03:02 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fertility_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `health_tips`
--

DROP TABLE IF EXISTS `health_tips`;
CREATE TABLE IF NOT EXISTS `health_tips` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `author` varchar(100) DEFAULT 'Admin',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menstrual_cycles`
--

DROP TABLE IF EXISTS `menstrual_cycles`;
CREATE TABLE IF NOT EXISTS `menstrual_cycles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `menstrual_cycles`
--

INSERT INTO `menstrual_cycles` (`id`, `user_id`, `start_date`, `end_date`) VALUES
(1, 3, '2025-02-14', '2025-03-22'),
(2, 3, '2025-02-20', '2025-02-23'),
(3, 4, '2025-02-18', '2025-03-12'),
(4, 4, '2025-02-04', '2025-02-10');

-- --------------------------------------------------------

--
-- Table structure for table `predicted_cycles`
--

DROP TABLE IF EXISTS `predicted_cycles`;
CREATE TABLE IF NOT EXISTS `predicted_cycles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `predicted_cycles`
--

INSERT INTO `predicted_cycles` (`id`, `user_id`, `start_date`, `end_date`) VALUES
(1, 4, '2025-03-26', '2025-03-31'),
(2, 4, '2025-04-09', '2025-04-14'),
(3, 4, '2025-04-23', '2025-04-28'),
(4, 4, '2025-03-26', '2025-03-31'),
(5, 4, '2025-04-09', '2025-04-14'),
(6, 4, '2025-04-23', '2025-04-28'),
(7, 4, '2025-03-26', '2025-03-31'),
(8, 4, '2025-04-09', '2025-04-14'),
(9, 4, '2025-04-23', '2025-04-28'),
(10, 4, '2025-03-26', '2025-03-31'),
(11, 4, '2025-04-09', '2025-04-14'),
(12, 4, '2025-04-23', '2025-04-28'),
(13, 4, '2025-03-26', '2025-03-31'),
(14, 4, '2025-04-09', '2025-04-14'),
(15, 4, '2025-04-23', '2025-04-28'),
(16, 4, '2025-03-26', '2025-03-31'),
(17, 4, '2025-04-09', '2025-04-14'),
(18, 4, '2025-04-23', '2025-04-28'),
(19, 4, '2025-03-26', '2025-03-31'),
(20, 4, '2025-04-09', '2025-04-14'),
(21, 4, '2025-04-23', '2025-04-28'),
(22, 4, '2025-03-26', '2025-03-31'),
(23, 4, '2025-04-09', '2025-04-14'),
(24, 4, '2025-04-23', '2025-04-28'),
(25, 4, '2025-03-26', '2025-03-31'),
(26, 4, '2025-04-09', '2025-04-14'),
(27, 4, '2025-04-23', '2025-04-28'),
(28, 4, '2025-03-26', '2025-03-31'),
(29, 4, '2025-04-09', '2025-04-14'),
(30, 4, '2025-04-23', '2025-04-28');

-- --------------------------------------------------------

--
-- Table structure for table `symptoms`
--

DROP TABLE IF EXISTS `symptoms`;
CREATE TABLE IF NOT EXISTS `symptoms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `symptom` varchar(255) NOT NULL,
  `date_logged` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `symptoms`
--

INSERT INTO `symptoms` (`id`, `user_id`, `symptom`, `date_logged`) VALUES
(1, 4, 'pain always', '2025-02-07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `cycle_length` int DEFAULT '28',
  `period_length` int DEFAULT '5',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `user_password`, `cycle_length`, `period_length`) VALUES
(1, 'ponje', 'moses@gmail.com', '$2y$10$fiFSiQ9Z3LG/k72DmeMkueR6jkp691Pb8gdBV25ZPrCzZIkBY4KsS', 28, 5),
(3, 'mlungu', 'leonard@gmail.com', '$2y$10$sGau.VAeYexlcajmrcoG..3pSNk612NyS6xamuIU3bQsFksnjRV6m', 28, 10),
(4, 'karonga', 'karonga@gmail.com', '$2y$10$Dt9EnIYAMaUdPi3UJeDhA.kgLF8uWBs1ziaTJbxR0zDoCCOYblOPC', 28, 5);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `menstrual_cycles`
--
ALTER TABLE `menstrual_cycles`
  ADD CONSTRAINT `menstrual_cycles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
