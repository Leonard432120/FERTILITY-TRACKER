<footer class="footer">
    <p>&copy; 2025 Fertility Tracker | All rights reserved</p>
</footer>

<style>
    .footer {
        background-color: #2a3d7f;
        color: white;
        text-align: center;
        padding: 15px 0;
        position: relative;
        width: 100%;
        bottom: 0;
    }
</style>

</body>
</html>
