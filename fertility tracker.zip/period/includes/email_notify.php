<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include Composer's autoloader
require 'C:\wamp64\www\Lacasu2\ponje\vendor\autoload.php';
include '../includes/connect.php';

// Fetch SMTP credentials securely (store them in environment variables or a config file)
$smtp_username = getenv('SMTP_USERNAME') ?: 'ict-01-25-22@unilia.ac.mw'; // Replace with your actual email username
$smtp_password = getenv('SMTP_PASSWORD') ?: 'jeak qzap jcuf yvgk'; // Replace with your actual email password

function sendEmailReminder($email, $subject, $message) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // SMTP host
        $mail->SMTPAuth = true;
        $mail->Username = $GLOBALS['smtp_username']; // SMTP username
        $mail->Password = $GLOBALS['smtp_password']; // SMTP password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('ict-01-25-22@unilia.ac.mw', 'Fertility Tracker');
        $mail->addAddress($email);
        $mail->Subject = $subject;
        $mail->Body = $message;
        $mail->isHTML(true); // Set email format to HTML

        $mail->send();
        echo "Email Sent Successfully to $email<br>";
    } catch (Exception $e) {
        echo "Error sending email to $email: " . $mail->ErrorInfo . "<br>";
    }
}

// Fetch users and send email reminders
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($user = $result->fetch_assoc()) {
        $user_id = $user['id'];
        $email = $user['email'];
        $cycle_length = $user['cycle_length'];

        // Get last cycle data for the user
        $sql_cycle = "SELECT * FROM menstrual_cycles WHERE user_id='$user_id' ORDER BY start_date DESC LIMIT 1";
        $result_cycle = $conn->query($sql_cycle);
        $cycle = $result_cycle->fetch_assoc();

        if ($cycle) {
            $next_period = date('Y-m-d', strtotime($cycle['start_date'] . " +$cycle_length days"));
            $today = date('Y-m-d');
            $days_left = (strtotime($next_period) - strtotime($today)) / (60 * 60 * 24);

            if ($days_left == 3) {
                $subject = "Your Next Period is Coming!";
                $message = "Your period is expected in 3 days. Stay prepared! <br><br><strong>Reminder:</strong> Make sure to track your cycle for better planning.";
                sendEmailReminder($email, $subject, $message);
            }
        }
    }
} else {
    echo "No users found.";
}
?>
