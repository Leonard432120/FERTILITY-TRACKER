<?php
session_start();
$user_id = $_SESSION['user_id'] ?? null;

if ($user_id) {
    include 'includes/connect.php';
    $sql = "SELECT * FROM users WHERE id='$user_id'";
    $result = $conn->query($sql);
    $user = $result->fetch_assoc();
} else {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fertility Tracker</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Navbar Styling */
        .navbar {
            background-color: #2a3d7f;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar .logo h2 {
            margin: 0;
            font-size: 22px;
        }

        .navbar .user-info {
            font-size: 16px;
        }

        .navbar .user-info a {
            color: white;
            margin-left: 15px;
            text-decoration: none;
            font-weight: bold;
        }

        .navbar .user-info a:hover {
            text-decoration: underline;
        }

        /* Body Padding to Prevent Overlap */
        body {
            padding-top: 60px; /* Adjust based on navbar height */
        }

        @media (max-width: 768px) {
            .navbar {
                flex-direction: column;
                text-align: center;
            }
            .navbar .user-info {
                margin-top: 5px;
            }
        }
    </style>
</head>
<body>
    <header class="navbar">
        <div class="logo">
            <h2>Fertility Tracker</h2>
        </div>
        <div class="user-info">
            <p>Welcome, <?php echo htmlspecialchars($user['name']); ?></p>
            <a href="users/logout.php">Logout</a>
        </div>
    </header>
</body>
</html>
