<?php
// Include database connection
include 'C:\wamp64\www\period\includes\connect.php';

// Check if user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');  // Redirect if not logged in
    exit();
}

// Fetch the user data from the database
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = '$user_id'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

// Check if form is submitted to update profile
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $cycle_length = $_POST['cycle_length'];
    $period_length = $_POST['period_length'];
    $email = $_POST['email'];

    // Update the user data in the database
    $update_sql = "UPDATE users SET name='$name', cycle_length='$cycle_length', period_length='$period_length', email='$email' WHERE id='$user_id'";
    if ($conn->query($update_sql) === TRUE) {
        echo "<p>Profile updated successfully!</p>";
    } else {
        echo "<p>Error updating profile: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="assests/css/style.css"> <!-- Your CSS file -->
</head>
<body>
    <h1>Edit Profile</h1>

    <form action="profile.php" method="POST">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($user['name']); ?>" required><br>

        <label for="cycle_length">Cycle Length (in days):</label>
        <input type="number" name="cycle_length" id="cycle_length" value="<?php echo htmlspecialchars($user['cycle_length']); ?>" required><br>

        <label for="period_length">Period Length (in days):</label>
        <input type="number" name="period_length" id="period_length" value="<?php echo htmlspecialchars($user['period_length']); ?>" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required><br>

        <input type="submit" value="Update Profile">
    </form>

    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
