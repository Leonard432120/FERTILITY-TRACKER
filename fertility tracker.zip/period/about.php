<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Fertility Tracker</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('https://asiapacific.unfpa.org/sites/default/files/mhm.22.2.011_0.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            color: #2a3d7f;
        }

        .sidebar {
            width: 200px;
            background-color: rgba(42, 61, 127, 0.9);
            color: #f0e4d7;
            padding: 20px;
            height: 100vh;
            position: fixed;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 1.5em;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px;
            text-align: center;
        }

        .sidebar ul li a {
            color: #f0e4d7;
            text-decoration: none;
            display: block;
            font-size: 1em;
        }

        .sidebar ul li:hover {
            background-color: rgba(240, 228, 215, 0.2);
        }

        .content-container {
            margin-left: 220px;
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .content-container h1 {
            font-size: 2.5em;
            background-color: rgba(240, 228, 215, 0.8);
            border-radius: 10px;
            padding: 10px;
            display: inline-block;
            color: #2a3d7f;
        }

        .content-container p {
            max-width: 800px;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="about_us.php">About Us</a></li>
            <li><a href="contact_us.php">Contact Us</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="content-container">
        <h1>About Us</h1>
        <p>Welcome to Fertility Tracker! We are dedicated to helping you manage your fertility and menstrual health with ease and accuracy. Our mission is to provide a reliable and user-friendly platform for tracking your menstrual cycles, identifying your fertile days, and staying informed about your reproductive health.</p>
        <p>We believe that knowledge is power, and our goal is to empower individuals to make informed decisions about their reproductive health. Whether you're planning a pregnancy, avoiding pregnancy, or simply wanting to understand your body's natural rhythms, Fertility Tracker is here to support you every step of the way.</p>
        <p>Thank you for choosing Fertility Tracker as your trusted companion in managing your reproductive health. We are committed to providing you with the best possible experience and are constantly working to improve our services.</p>
    </div>
</body>
</html>
