<?php
//include 'includes/header.php';
include 'includes/connect.php';
session_start();

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id='$user_id'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

$sql_cycle = "SELECT * FROM menstrual_cycles WHERE user_id='$user_id' ORDER BY start_date DESC LIMIT 1";
$result_cycle = $conn->query($sql_cycle);
$cycle = $result_cycle->fetch_assoc();

if ($cycle) {
    $cycle_length = $user['cycle_length'];
    $period_length = $user['period_length'];
    $start_date = $cycle['start_date'];

    // Period & Fertile Window
    $period_end = date('Y-m-d', strtotime($start_date . " +{$period_length} days"));
    $ovulation_day = date('Y-m-d', strtotime($start_date . " +14 days"));
    $fertile_start = date('Y-m-d', strtotime($ovulation_day . ' -3 days'));
    $fertile_end = date('Y-m-d', strtotime($ovulation_day . ' +1 days'));

    // Safe Days
    $safe_before = date('Y-m-d', strtotime($start_date . " -5 days"));
    $safe_after = date('Y-m-d', strtotime($fertile_end . " +3 days"));

    // JSON Data for Chart
    $chart_data = json_encode([
        ["label" => "Period Days", "value" => $period_length],
        ["label" => "Fertile Window", "value" => 5],
        ["label" => "Safe Days", "value" => ($cycle_length - ($period_length + 5))]
    ]);
} else {
    $no_data_message = "No cycle data found. Please track your cycle first.";
}

include 'includes/footer.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Safe Days - Menstrual Tracker</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('https://asiapacific.unfpa.org/sites/default/files/mhm.22.2.011_0.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .navbar {
            background-color: rgba(42, 61, 127, 0.8);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: center;
            width: 100%;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .info-cards {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .card {
            background-color: rgba(42, 61, 127, 0.8);
            color: #f0e4d7;
            padding: 15px;
            border-radius: 10px;
            width: 200px;
            margin: 10px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }

        .card img {
            width: 80px;
            height: auto;
            margin-bottom: 10px;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .footer {
            background-color: rgba(42, 61, 127, 0.8);
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        button.notification {
            background-color: rgba(42, 61, 127, 0.8);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
        }

        button.notification:hover {
            background-color: rgba(42, 61, 127, 1);
        }

        .nav-links {
            margin-top: 20px;
        }

        .nav-links a {
            display: inline-block;
            background: rgba(42, 61, 127, 0.8);
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            margin: 5px;
            border-radius: 5px;
            font-weight: bold;
            transition: background 0.3s;
        }

        .nav-links a:hover {
            background: rgba(42, 61, 127, 1);
        }

        .no-data {
            color: red;
            font-weight: bold;
            margin-top: 20px;
        }

        /* New Feature: Tips for Safe Days */
        .tips {
            background: rgba(42, 61, 127, 0.1);
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
            text-align: left;
        }

        .tips h2 {
            color: #2a3d7f;
        }

        .tips ul {
            padding-left: 20px;
        }

        .tips ul li {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h2>Your Safe Days</h2>
    </div>

    <div class="container">
        <h1>Your Safe Days</h1>

        <?php if (isset($no_data_message)) { ?>
            <p class="no-data"><?php echo $no_data_message; ?></p>
        <?php } else { ?>
            <div class="info-cards">
                <div class="card">
                    <img src="https://cdn-icons-png.flaticon.com/512/4825/4825073.png" alt="Safe Before Icon">
                    <h2>Safe Before</h2>
                    <p><strong>Before <?php echo $fertile_start; ?></strong></p>
                </div>
                <div class="card">
                    <img src="https://cdn-icons-png.flaticon.com/512/3135/3135722.png" alt="Safe After Icon">
                    <h2>Safe After</h2>
                    <p><strong>After <?php echo $safe_after; ?></strong></p>
                </div>
            </div>

            <h2>Cycle Overview</h2>
            <canvas id="cycleChart"></canvas>

            <button class="notification" onclick="notifyUser()">Notify Me</button>

            <div class="tips">
                <h2>Tips for Safe Days</h2>
                <ul>
                    <li>Track your cycle regularly to understand your safe days better.</li>
                    <li>Use additional contraception methods during the fertile window.</li>
                    <li>Maintain a healthy lifestyle to regulate your menstrual cycle.</li>
                    <li>Consult with a healthcare provider for personalized advice.</li>
                </ul>
            </div>
        <?php } ?>

        <div class="nav-links">
            <a href="index.php">Back to Dashboard</a>
            <a href="fertile.php">Check Fertile Days</a>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            let chartData = <?php echo $chart_data; ?>;

            let ctx = document.getElementById('cycleChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: chartData.map(d => d.label),
                    datasets: [{
                        label: 'Days',
                        data: chartData.map(d => d.value),
                        backgroundColor: ['#ff6384', '#ffcc56', '#36a2eb']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });

        function notifyUser() {
            alert('You will be notified about your safe days.');
        }
    </script>
</body>
</html>
