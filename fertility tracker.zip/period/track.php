<?php
include 'includes/connect.php';
session_start();

if (isset($_POST['submit'])) {
    $user_id = $_SESSION['user_id'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Validate date input
    if ($start_date > $end_date) {
        echo "<p style='color: red;'>Error: Start date must be before end date.</p>";
        return;
    }

    $sql = "INSERT INTO menstrual_cycles (user_id, start_date, end_date)
            VALUES ('$user_id', '$start_date', '$end_date')";

    if ($conn->query($sql) === TRUE) {
        echo "<p style='color: green;'>Cycle saved successfully!</p>";
    } else {
        echo "<p style='color: red;'>Error: " . $conn->error . "</p>";
    }
}

$user_id = $_SESSION['user_id'];
$sql_history = "SELECT * FROM menstrual_cycles WHERE user_id='$user_id' ORDER BY start_date DESC";
$result_history = $conn->query($sql_history);
$cycles = [];
while ($row = $result_history->fetch_assoc()) {
    $cycles[] = $row;
}

$predicted_cycles = [];
if (count($cycles) >= 2) {
    $average_cycle_length = 0;
    $cycle_count = count($cycles) - 1;
    for ($i = 0; $i < $cycle_count; $i++) {
        $start_date = new DateTime($cycles[$i]['start_date']);
        $next_start_date = new DateTime($cycles[$i + 1]['start_date']);
        $average_cycle_length += $next_start_date->diff($start_date)->days;
    }
    $average_cycle_length = $average_cycle_length / $cycle_count;

    $last_cycle_end_date = new DateTime($cycles[0]['end_date']);
    for ($i = 1; $i <= 3; $i++) {
        $predicted_start_date = clone $last_cycle_end_date;
        $predicted_start_date->modify('+' . ($average_cycle_length * $i) . ' days');
        $predicted_end_date = clone $predicted_start_date;
        $predicted_end_date->modify('+5 days');
        $predicted_cycles[] = [
            'start_date' => $predicted_start_date->format('Y-m-d'),
            'end_date' => $predicted_end_date->format('Y-m-d')
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Your Menstrual Cycle</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('https://asiapacific.unfpa.org/sites/default/files/mhm.22.2.011_0.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .dashboard {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 20px;
            width: 90%;
            max-width: 1200px;
        }

        header {
            text-align: center;
            margin-bottom: 20px;
        }

        .info-cards, .cycle-history, .prediction-table, .notification-settings {
            margin-bottom: 20px;
        }

        .card {
            position: relative;
            background-image: url('image/dashboard.jpg');
            background-size: 100% auto;
            background-position: center;
            background-repeat: no-repeat;
            width: 95%;
            color: #f0e4d7;
            border-radius: 10px;
            padding: 20px;
            margin: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.2s;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1;
            border-radius: 10px;
        }

        .card * {
            position: relative;
            z-index: 2;
        }

        .card img {
            width: 60px;
            height: 60px;
            margin-bottom: 10px;
        }

        .card:hover {
            transform: scale(1.05);
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        label {
            margin: 10px 0;
            font-weight: bold;
        }

        input[type="date"] {
            padding: 5px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid rgba(42, 61, 127, 0.8);
        }

        button[type="submit"], .button {
            background-color: rgba(42, 61, 127, 0.8);
            color: #f0e4d7;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button[type="submit"]:hover, .button:hover {
            background-color: rgba(42, 61, 127, 1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid rgba(42, 61, 127, 0.8);
        }

        th {
            background-color: rgba(42, 61, 127, 0.8);
            color: #f0e4d7;
        }

        .progress-bar-container {
            width: 100%;
            background-color: rgba(42, 61, 127, 0.1);
            border-radius: 10px;
            margin: 20px 0;
        }

        .progress-bar {
            height: 20px;
            background-color: rgba(42, 61, 127, 0.8);
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <header>
            <h1>Track Your Menstrual Cycle</h1>
        </header>

        <div class="info-cards">
            <div class="card">
                <img src="https://cdn-icons-png.flaticon.com/512/4825/4825073.png" alt="Period Icon">
                <form method="POST">
                    <label for="start_date">Start Date:</label>
                    <input type="date" name="start_date" required>
                    <label for="end_date">End Date:</label>
                    <input type="date" name="end_date" required>
                    <button type="submit" name="submit">Save</button>
                </form>
            </div>
        </div>

        <div class="cycle-history">
            <h2>Cycle History</h2>
            <table>
                <thead>
                    <tr>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Duration (days)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cycles as $cycle): ?>
                        <tr>
                            <td><?php echo $cycle['start_date']; ?></td>
                            <td><?php echo $cycle['end_date']; ?></td>
                            <td><?php echo (new DateTime($cycle['end_date']))->diff(new DateTime($cycle['start_date']))->days; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="progress-bar-container">
            <div class="progress-bar" id="progressBar"></div>
        </div>

        <div class="notification-settings">
            <h2>Notification Settings</h2>
            <form>
                <label for="notification">Notify me before the next cycle starts:</label>
                <select name="notification" id="notification">
                    <option value="1">1 day before</option>
                    <option value="2">2 days before</option>
                    <option value="3">3 days before</option>
                </select>
                <button type="submit" class="button">Set Notification</button>
            </form>
        </div>

        <div class="prediction-table">
            <h2>Predicted Future Cycles</h2>
            <table>
                <thead>
                    <tr>
                    <th>Predicted Start Date</th>
                <th>Predicted End Date</th>
                <th>Duration (days)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($predicted_cycles as $cycle): ?>
                <tr>
                    <td><?php echo $cycle['start_date']; ?></td>
                    <td><?php echo $cycle['end_date']; ?></td>
                    <td>5</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Calculate progress of the current cycle and update progress bar
    window.onload = function() {
        var startDate = new Date("<?php echo $cycles[0]['start_date'] ?? ''; ?>");
        var endDate = new Date("<?php echo $cycles[0]['end_date'] ?? ''; ?>");
        var today = new Date();

        if (startDate && endDate && today >= startDate && today <= endDate) {
            var totalDays = (endDate - startDate) / (1000 * 60 * 60 * 24);
            var daysPassed = (today - startDate) / (1000 * 60 * 60 * 24);
            var progressPercentage = (daysPassed / totalDays) * 100;
            document.getElementById('progressBar').style.width = progressPercentage + "%";
        }

        // Graphical representation of cycles
        var ctx = document.getElementById('cycleChart').getContext('2d');
        var cycleChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($cycles, 'start_date')); ?>,
                datasets: [{
                    label: 'Cycle Duration (days)',
                    data: <?php echo json_encode(array_map(function($cycle) {
                        return (new DateTime($cycle['end_date']))->diff(new DateTime($cycle['start_date']))->days;
                    }, $cycles)); ?>,
                    backgroundColor: 'rgba(214, 51, 132, 0.2)',
                    borderColor: 'rgba(214, 51, 132, 1)',
                    borderWidth: 1,
                    fill: false
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    };
</script>

<canvas id="cycleChart" width="400" height="200"></canvas>

</body>
</html>
