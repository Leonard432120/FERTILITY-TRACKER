<?php
include 'includes/connect.php';
session_start();

// Check if user is logged in as admin
if (!isset($_SESSION['admin'])) {
    die("Access Denied. Admins only.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $author = $_POST['author'];

    $sql = "INSERT INTO health_tips (title, content, author) VALUES ('$title', '$content', '$author')";
    if ($conn->query($sql)) {
        echo "<p>Health tip added successfully!</p>";
    } else {
        echo "<p>Error: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Health Tip</title>
</head>
<body>
    <h1>Add a New Health Tip</h1>

    <form action="add_health_tip.php" method="POST">
        <label for="title">Title:</label>
        <input type="text" name="title" required><br>

        <label for="content">Content:</label>
        <textarea name="content" required></textarea><br>

        <label for="author">Author:</label>
        <input type="text" name="author" value="Admin"><br>

        <input type="submit" value="Add Tip">
    </form>

    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
