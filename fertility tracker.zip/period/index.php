<?php
include 'includes/header.php';
include 'includes/connect.php';
//session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: users/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id='$user_id'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

$sql_cycle = "SELECT * FROM menstrual_cycles WHERE user_id='$user_id' ORDER BY start_date DESC LIMIT 1";
$result_cycle = $conn->query($sql_cycle);
$cycle = $result_cycle->fetch_assoc();

if ($cycle) {
    $next_period = date('Y-m-d', strtotime($cycle['start_date'] . " +{$user['cycle_length']} days"));
} else {
    $no_data_message = "No cycle data found. Please track your cycle.";
}

include 'includes/footer.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - Menstrual Tracker</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f5;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #2a3d7f;
            padding: 10px;
            color: white;
            text-align: center;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #2a3d7f;
        }

        .info-cards {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .card {
            background: #e7eff7;
            padding: 15px;
            border-radius: 10px;
            width: 200px;
            margin: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card h2 {
            font-size: 18px;
            color: #2a3d7f;
            margin-bottom: 5px;
        }

        .card p {
            font-size: 16px;
            color: #666;
        }

        .nav-links {
            margin-top: 20px;
            text-align: center;
        }

        .nav-links a {
            display: inline-block;
            background: #2a3d7f;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            margin: 5px;
            border-radius: 5px;
            font-weight: bold;
            transition: background 0.3s;
        }

        .nav-links a:hover {
            background: #1d2d6a;
        }

        .no-data {
            color: red;
            font-weight: bold;
            margin-top: 20px;
        }

        .footer {
            background-color: #2a3d7f;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <div class="navbar">
        <h2>Welcome to the Fertility Tracker</h2>
    </div>

    <!-- Main Container -->
    <div class="container">
        <h1>Welcome, <?php echo htmlspecialchars($user['name']); ?>!</h1>

        <?php if (isset($no_data_message)) { ?>
            <p class="no-data"><?php echo $no_data_message; ?></p>
        <?php } else { ?>
            <div class="info-cards">
                <div class="card">
                    <h2>Last Period Start</h2>
                    <p><strong><?php echo $cycle['start_date']; ?></strong></p>
                </div>
                <div class="card">
                    <h2>Next Expected Period</h2>
                    <p><strong><?php echo $next_period; ?></strong></p>
                </div>
            </div>
        <?php } ?>

        <div class="nav-links">
            <a href="track.php">Track Your Cycle</a>
            <a href="fertile.php">Check Fertile Days</a>
            <a href="safe-days.php">See Safe Days</a>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2025 Fertility Tracker | All rights reserved</p>
    </div>

</body>
</html>
